<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TypeGarage extends Model
{
    //
    protected $fillable = ['name'];
}
