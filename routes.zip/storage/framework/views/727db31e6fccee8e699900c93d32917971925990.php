<?php $__env->startSection('title', 'Sale Manage'); ?>
<?php $__env->startSection('content'); ?>

<!-- NavBar -->
<?php echo $__env->make('include.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Section Sale Manage -->
<section id="sale-manage">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <h1>Post Your Garage Sale For Free</h1>
        <hr>
        <sale-manage url="<?php echo e(URL::current()); ?>"></sale-manage>
      </div>
    </div>
  </div>
</section>


<?php echo $__env->make('include.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<script async defer
          src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCZvuQnalxu6pzgdPVSpS2j3dEvP_hv8NM">
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>