<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('content'); ?>

<!-- NavBar -->
<?php echo $__env->make('include.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!--  Section Header -->
<section id="header" class="mt-5">
    <div class="jumbotron jumbotron-fluid">
        <div class="container">
            <h1 class="text-center display-4">Find garage sales near you!</h1>
            <form action="" class="form-inline justify-content-center my-4">
                <input type="text" class="form-control form-control-lg mb-2 mr-sm-2" id="inlineFormInputName2" placeholder="Address or Zip Code">
                <button class="btn btn-outline-primary mb-2">Buscar</button>
            </form>
            <p class="lead text-center">Having a sale of your own?
                <a href="<?php echo e(route('sale.manage')); ?>">List it here for free!</a>
            </p>
        </div>
    </div>
</section>

<!-- Section Contenido -->
<section id="Contenido" class="my-4">

    <div class="container">
        <div class="row">
            <div class="col-md-12">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Officia numquam accusamus ea, nam, amet tempora laborum illo, saepe
                ullam vel ipsam blanditiis possimus. Exercitationem inventore unde facere nobis earum ea. Lorem ipsum dolor
                sit amet consectetur adipisicing elit. Fuga recusandae perspiciatis enim, nemo minima voluptatibus neque
                assumenda voluptate nulla impedit, modi eaque autem aut facilis magni nihil quo necessitatibus dignissimos?
            </div>
        </div>
    </div>

</section>

<section id="last-garage" class="my-4">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h3>Last Garage</h3>
                <hr>
                <div class="card-group">
                    <?php $__currentLoopData = $garages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $garage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card mx-1">
                            <img class="card-img-top" src="<?php echo e(asset('img/photos/'.$garage->images[0]->name)); ?>" alt="Card image cap">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo e($garage->title); ?></h5>
                                <p class="card-text"><?php echo e(str_limit($garage->description, 100)); ?></p>
                                <p class="card-text"><strong>Hour:</strong> <?php echo e(Carbon\Carbon::parse($garage->starthour)->format('H:i A')); ?> / <?php echo e(Carbon\Carbon::parse($garage->endhour)->format('H:i A')); ?></p>
                                <p class="card-text"><strong>Address:</strong> <?php echo e($garage->address); ?></p>
                                <p class="card-text"><strong>City:</strong> <?php echo e($garage->city); ?></p>
                                <p class="card-text"><strong>State:</strong> <?php echo e($garage->state->name); ?></p>
                                <p class="card-text">
                                    <?php $__currentLoopData = $garage->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <small class="badge badge-info text-uppercase mx-1"><?php echo e($tag->name); ?></small>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </p>
                            <p class="card-text"><a href="<?php echo e(route('show', $garage->id)); ?>" class="btn btn-primary btn-block">More Info</a></p>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</section>

<section id="find-yard-sales" class="my-4">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h3>List of cities in Los Angeles County, California</h3>
                <hr>
            </div>
            <div class="col-md-3">
                <ul class="list-group">
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Agoura Hills')); ?>">Agoura Hills</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Alhambra')); ?>">Alhambra</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Arcadia')); ?>">Arcadia</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Artesia')); ?>">Artesia</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Avalon')); ?>">Avalon</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Azusa')); ?>">Azusa</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Bell')); ?>">Bell</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Bell Gardens')); ?>">Bell Gardens</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Bellflower')); ?>">Bellflower</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Beverly Hills')); ?>">Beverly Hills</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Bradbury')); ?>">Bradbury</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Burbank')); ?>">Burbank</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Carson')); ?>">Carson</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Cerritos')); ?>">Cerritos</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Claremont')); ?>">Claremont</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Commerce')); ?>">Commerce</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Compton')); ?>">Compton</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Covina')); ?>">Covina</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Cudahy')); ?>">Cudahy</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Culver City')); ?>">Culver City</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Diamond Bar')); ?>">Diamond Bar</a>
                    </li>
                </ul>
            </div>
            <div class="col-md-3">
                <ul class="list-group">
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Downey')); ?>">Downey</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Duarte')); ?>">Duarte</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'El Monte')); ?>">El Monte</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'El Segundo')); ?>">El Segundo</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Gardena')); ?>">Gardena</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Glendale')); ?>">Glendale</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Glendora')); ?>">Glendora</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Hawaiian Gardens')); ?>">Hawaiian Gardens</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Hawthorne')); ?>">Hawthorne</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Hermosa Beach')); ?>">Hermosa Beach</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Hidden Hills')); ?>">Hidden Hills</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Huntington Park')); ?>">Huntington Park</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Industry')); ?>">Industry</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Inglewood')); ?>">Inglewood</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Irwindale')); ?>">Irwindale</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'La Cañada Flintridge')); ?>">La Cañada Flintridge</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'La Habra Heights')); ?>">La Habra Heights</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'La Mirada')); ?>">La Mirada</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'La Puente')); ?>">La Puente</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'La Verne')); ?>">La Verne</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Lakewood')); ?>">Lakewood</a>
                    </li>
                </ul>
            </div>
            <div class="col-md-3">
                <ul class="list-group">
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Lancaster')); ?>">Lancaster</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Lawndale')); ?>">Lawndale</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Lomita')); ?>">Lomita</a>
                    </li>

                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Long Beach')); ?>">Long Beach</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Los Angeles')); ?>">Los Angeles</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Lynwood')); ?>">Lynwood</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Malibu')); ?>">Malibu</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Manhattan Beach')); ?>">Manhattan Beach</a>
                    </li>

                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Maywood')); ?>">Maywood</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Monrovia')); ?>">Monrovia</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Montebello')); ?>">Montebello</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Monterey Park')); ?>">Monterey Park</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Norwalk')); ?>">Norwalk</a>
                    </li>

                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Palmdale')); ?>">Palmdale</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Palos Verdes')); ?>">Palos Verdes</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Paramount')); ?>">Paramount</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Pasadena')); ?>">Pasadena</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Pico Rivera')); ?>">Pico Rivera</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Pomona')); ?>">Pomona</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Redondo Beach')); ?>">Redondo Beach</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Rolling Hills')); ?>">Rolling Hills</a>
                    </li>
                </ul>
            </div>
            <div class="col-md-3">
                <ul class="list-group">
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Rosemead')); ?>">Rosemead</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'San Dimas')); ?>">San Dimas</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'San Fernando')); ?>">San Fernando</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'San Gabriel')); ?>">San Gabriel</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'San Marino')); ?>">San Marino</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Santa Clarita')); ?>">Santa Clarita</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Santa Fe Springs')); ?>">Santa Fe Springs</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Santa Monica')); ?>">Santa Monica</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Sierra Madre')); ?>">Sierra Madre</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Signal Hill')); ?>">Signal Hill</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'El Monte')); ?>">El Monte</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'South Gate')); ?>">South Gate</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Temple City')); ?>">Temple City</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Torrance')); ?>">Torrance</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Vernon')); ?>">Vernon</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Walnut')); ?>">Walnut</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'West Covina')); ?>">West Covina</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Maywood')); ?>">Maywood</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'West Hollywood')); ?>">West Hollywood</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'West Hollywood')); ?>">Westlake Village</a>
                    </li>
                    <li class="list-group-item list-group-item-action">
                        <a href="<?php echo e(route('address', 'Whittier')); ?>">Whittier</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</section>

<?php echo $__env->make('include.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>