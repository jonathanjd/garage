<?php $__env->startSection('title', 'Contact'); ?>
<?php $__env->startSection('content'); ?>

<!-- NavBar -->
<?php echo $__env->make('include.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Section Contact -->
<section id="contact">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="card border-primary mb-3">
          <div class="card-header">Info Garage</div>
          <div class="card-body">
              <div class="text-right">
              <a href="<?php echo e(route('home')); ?>" class="btn btn-primary">Back</a>
              </div>
                <show-garage id="<?php echo e($id); ?>"></show-garage>
              <div class="text-right">
                <a href="<?php echo e(route('home')); ?>" class="btn btn-primary">Back</a>
              </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<?php echo $__env->make('include.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<script async defer
          src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCZvuQnalxu6pzgdPVSpS2j3dEvP_hv8NM">
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>