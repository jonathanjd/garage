<footer class="footer bg-dark">
      <div class="container">
        <span class="text-light">&copy; 2018 garagesale.com</span>
      </div>
</footer>