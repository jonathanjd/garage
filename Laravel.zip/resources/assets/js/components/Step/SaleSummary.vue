<template>
<div>
  <transition-group name="fade" appear>
    <div class="mt-4" key="box1">
      <h3>Sale Summary</h3>
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. A exercitationem omnis quidem officia, consequuntur numquam pariatur iure commodi quia laboriosam tempora aliquam nisi! Accusantium, reprehenderit? Laborum atque at quisquam incidunt.</p>
    </div>
  </transition-group>
  <div class="mt-4">
    <button type="button" class="btn btn-primary">OK</button>
  </div>
</div>
</template>

<script>
export default {

}
</script>

<style>
</style>
