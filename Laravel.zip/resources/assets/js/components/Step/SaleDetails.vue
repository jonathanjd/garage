<template>
<div>
  <transition-group name="fade" appear>
    <div class="mt-4" key="box1">
      <h3>Enter your sale details</h3>
      <p>Try to list as many items as you can in the description. When buyers search for sales with certain items like "bike" or "tools", your sale will only appear if you add those words to your description. Then click Next to proceed to the Photos step.</p>
    </div>
    <div class="card border-primary mt-4" key="box2">
        <div class="card-body">
          <h4>Sale Details</h4>
            <div class="form-group">
              <label for="">Type</label>
              <select class="form-control" v-model="type">
                <option :value="type" v-for="type in types">{{ type }}</option>
              </select>
            </div>
            <div class="form-group">
              <label for="">Title</label>
              <input v-model="title" class="form-control" type="text">
            </div>
            <div class="form-group">
              <label for="">Description</label>
              <textarea v-model="description" class="form-control"></textarea>
            </div>
        </div>
    </div>
    <div class="card border-primary mt-4" key="box3">
        <div class="card-body">
          <h4>Date & Times</h4>
          <div class="row">
            <div class="col">
              <div class="form-group">
                <label for="">Start Date</label>
                <datepicker name="datepicker1" v-model="startDate" input-class="form-control" :value="startDate"></datepicker>
              </div>
            </div>
            <div class="col">
              <div class="form-group">
                <label for="">End Date</label>
                <datepicker name="datepicker2" v-model="endDate" input-class="form-control" :value="endDate"></datepicker>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col">
              <div class="form-group">
                <label for="">Start Hour</label>
                <select v-model="startHour" class="form-control">
                  <option :value="hour" v-for="(hour, index) in baseHour">{{ hour }}</option>
                </select>
              </div>
            </div>
            <div class="col">
              <div class="form-group">
                <label for="">End Hour</label>
                <select v-model="endHour" class="form-control">
                  <option :value="hour" v-for="(hour, index) in baseHour">{{ hour }}</option>
                </select>
              </div>
            </div>
          </div>
        </div>
    </div>
  </transition-group>
  <div class="mt-4">
    <button @click="cancel" class="btn btn-outline-dark">Cancel</button>
    <button @click="next" class="btn btn-primary">Next</button>
  </div>
</div>
</template>

<script>
import Datepicker from 'vuejs-datepicker';
import { hours } from '../../data/hours.js';

export default {
  data() {
    return {
      types: [
        'Garage/Yard Sale',
        'Moving Sale',
        'Multi-family Sale',
        'Estate Sale',
        'Neighborhood Sale',
        'Business',
        'Other'
      ],
      title: '',
      description: '',
      type: 'Garage/Yard Sale',
      startDate: '',
      endDate: '',
      startHour: '8:00 AM',
      endHour: '5:00 PM',
      diffDate: 0,
      baseHour: null
    };
  },

  created() {
    this.startDate = this.$moment().format('YYYY-MM-DD');
    this.endDate = this.$moment().format('YYYY-MM-DD');
    this.baseHour = hours;
  },

  computed: {
    myDiffDate() {
      let a = this.$moment(this.startDate);
      let b = this.$moment(this.endDate);
      return Math.abs(a.diff(b, 'days')) + 1;
    }
  },

  components: {
    Datepicker
  },

  methods: {
    next() {
      const data = {
        title: this.title,
        description: this.description,
        type: this.type,
        startDate: this.$moment(this.startDate).format('YYYY-MM-DD'),
        endDate: this.$moment(this.endDate).format('YYYY-MM-DD'),
        startHour: this.startHour,
        endHour: this.endHour,
      };

      this.$store.dispatch('loadGarageDataBasic', data);
      EventBus.$emit('changeComponent', 'appSalePhotos', '70%');
    },

    cancel() {
      EventBus.$emit('changeComponent', 'appSaleLocation', '20%');
    }
  }
};
</script>

<style>
</style>
