<template>
  <div
        class="tab-pane fade"
        id="accountSettings"
        role="tabpanel"
        aria-labelledby="account-setting"
      >
        <div class="row">
          <div class="col-md-12">
            <div class="card mt-4">
              <div class="card-body">
                <h3>Change Your Password</h3>
                <form action="">
                  <div class="form-group">
                    <label htmlFor="">New Password</label>
                    <input type="text" class="form-control" />
                  </div>
                </form>
                <button class="btn btn-success">Save</button>
              </div>
            </div>
          </div>
        </div>
      </div>
</template>

<script>
export default {

}
</script>

<style>
</style>
