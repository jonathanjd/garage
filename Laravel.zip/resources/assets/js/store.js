import Vue from 'vue';
import Vuex from 'vuex';

Vue.use(Vuex);

export const store = new Vuex.Store({
  // ...
  state: {
    garageData: {
      location: {
        lat: null,
        lng: null
      },
      title: null,
      description: null,
      type: null,
      startDate: null,
      endDate: null,
      startHour: null,
      endHour: null,
      photos:[]
    }
  },

  mutations: {

    setGarageLocationLat(state, payload){
      state.garageData.location.lat = payload
    },

    setGarageLocationLng(state, payload){
      state.garageData.location.lng = payload
    },

    setGarageTitle(state, payload){
      state.garageData.title = payload
    },

    setGarageDescription(state, payload){
      state.garageData.description = payload
    },

    setGarageType(state, payload){
      state.garageData.type = payload
    },

    setGarageStartDate(state, payload){
      state.garageData.startDate = payload
    },

    setGarageEndDate(state, payload){
      state.garageData.endDate = payload
    },

    setGarageStartHour(state, payload){
      state.garageData.startHour = payload
    },

    setGarageEndHour(state, payload){
      state.garageData.endHour = payload
    },

    setGaragePhotos(state, payload){
      state.garageData.photos = payload
    },

  },

  getters: {

  },

  actions: {
    loadGarageLocationLat({commit}, payload){
      commit('setGarageLocationLat', payload);
    },
    loadGarageLocationLng({commit}, payload){
      commit('setGarageLocationLng', payload);
    },

    loadGarageDataBasic({commit}, payload){
      commit('setGarageTitle', payload.title);
      commit('setGarageDescription', payload.description);
      commit('setGarageType', payload.type);
      commit('setGarageStartDate', payload.startDate);
      commit('setGarageEndDate', payload.endDate);
      commit('setGarageStartHour', payload.startHour);
      commit('setGarageEndHour', payload.endHour);
    },

    loadGaragePhotos({commit}, payload){
      commit('setGaragePhotos', payload.photos);
    },
  }

})

