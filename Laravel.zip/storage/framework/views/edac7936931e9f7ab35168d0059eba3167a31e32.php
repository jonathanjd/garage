<nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-dark">
<a class="navbar-brand" href="<?php echo e(route('home')); ?>">Garage Sale</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
    aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item <?php echo e(url()->current() == url('/') ? 'active' : ''); ?>">
      <a class="nav-link" href="<?php echo e(route('home')); ?>">Home
          <span class="sr-only">(current)</span>
        </a>
      </li>
      <li class="nav-item <?php echo e(url()->current() == url('yard-sales') ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('yard.sales')); ?>">I'm a Shopper</a>
      </li>
      <li class="nav-item <?php echo e(url()->current() == url('sale-manage') ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('sale.manage')); ?>">I'm a Seller</a>
      </li>
      <li class="nav-item <?php echo e(url()->current() == url('tips') ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('tips')); ?>">Tips</a>
      </li>
      <li class="nav-item <?php echo e(url()->current() == url('contact') ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('contact')); ?>">Contact</a>
      </li>

    </ul>
    <ul class="navbar-nav justify-content-end">
      <?php if(auth()->guard()->guest()): ?>
        <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('login')); ?>">Sign In</a>
        </li>
        <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('register')); ?>">Register</a>
        </li>
      <?php else: ?>
      <li class="nav-item <?php echo e(url()->current() == url('admin/dashboard') ? 'active' : ''); ?>">
          <a class="nav-link" href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
          </li>
          <li class="nav-item">
          <a
            class="nav-link"
            href="<?php echo e(route('logout')); ?>"
            onclick="event.preventDefault();document.getElementById('logout-form').submit();"
          >Logout</a>
          <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
              <?php echo e(csrf_field()); ?>

          </form>
          </li>
      <?php endif; ?>
    </ul>
  </div>
</nav>