<?php $__env->startSection('title', 'Yard Sales'); ?>
<?php $__env->startSection('content'); ?>

<!-- NavBar -->
<?php echo $__env->make('include.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Section Yard-Sale -->
<section id="yard-sale">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
        <h1>I'm a Shopper</h1>
        <hr>
        <yard-sale></yard-sale>
      </div>
    </div>
  </div>
</section>

<?php echo $__env->make('include.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>