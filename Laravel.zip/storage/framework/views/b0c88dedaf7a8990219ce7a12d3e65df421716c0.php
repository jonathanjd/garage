<?php $__env->startSection('title', 'Login'); ?>
<?php $__env->startSection('content'); ?>

<!-- NavBar -->
<?php echo $__env->make('include.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Section Contact -->
<section id="contact">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="card mb-3">
        <img class="card-img-top" src="<?php echo e(asset('img/login.png')); ?>" alt="Card image cap">
          <div class="card-body">
            <h1>Sign In</h1>
            <form class="form-horizontal" method="POST" action="<?php echo e(route('login')); ?>">
              <?php echo e(csrf_field()); ?>

              <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                <label for="email">Email</label>
                <input type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
                <?php if($errors->has('email')): ?>
                  <span class="help-block">
                      <strong><?php echo e($errors->first('email')); ?></strong>
                  </span>
                <?php endif; ?>
              </div>
              <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                <label for="password">Password</label>
                <input type="password" class="form-control" name="password" required>
                <?php if($errors->has('password')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('password')); ?></strong>
                    </span>
                <?php endif; ?>
              </div>
              <div class="form-group">
                <div>
                    <div class="checkbox">
                        <label>
                            <input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> Remember Me
                        </label>
                    </div>
                </div>
            </div>
              <p>Forgot your password? <a href="<?php echo e(route('password.request')); ?>" class="">Recover Here.</a></p>
              <button type="submit" class="btn btn-primary">Login</button>
              <button type="button" class="btn btn-outline-primary">Cancel</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<?php echo $__env->make('include.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>